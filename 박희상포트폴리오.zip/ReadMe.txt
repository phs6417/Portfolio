1. CoronaMap (https://github.com/phs6417/coronaMAP-1)

2. Intern
 - 보안 계약으로 인하여 코드 공개 불가
 - 아이디어 상품의 경우 설명 불가
3. Capstone (https://github.com/phs6417/2018-cap1-15)

---------------------
지원자 : 박희상
phone : 010-5000-6417
mail: 	phs6417@naver.com
	show7159@gmail.com
깃허브 주소: https://github.com/phs6417